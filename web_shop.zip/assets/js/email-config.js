/*
    EMAIL-CONFIG.JS — Inicialización de EmailJS
    Autor: Juan David Parra Cantor
    Descripción:
        Este archivo se encarga únicamente de inicializar
        el servicio EmailJS con la Public Key del proyecto.
*/

(function () {
    emailjs.init("gj8TMdXOaWDqBYHnp");
})();
